package CatsPrograming.ReCore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReCoreApplication.class, args);
	}

}
